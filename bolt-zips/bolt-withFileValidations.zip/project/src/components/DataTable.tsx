import React, { useMemo, useState } from 'react';
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  flexRender,
  ColumnDef,
  SortingState,
  ColumnResizeMode,
  VisibilityState,
  Header,
  HeaderGroup,
} from '@tanstack/react-table';
import { ArrowUpDown, Search, Eye, EyeOff, ChevronDown, ChevronRight } from 'lucide-react';

interface ColumnGroup {
  id: string;
  title: string;
  columns: string[];
  isVisible?: boolean;
  subGroups?: ColumnGroup[];
}

interface DataTableProps {
  data: any[];
  columns: string[];
  initialColumnGroups?: ColumnGroup[];
}

export const DataTable: React.FC<DataTableProps> = ({ 
  data, 
  columns,
  initialColumnGroups = []
}) => {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [globalFilter, setGlobalFilter] = useState('');
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [columnResizeMode] = useState<ColumnResizeMode>('onChange');
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [columnGroups, setColumnGroups] = useState<ColumnGroup[]>(initialColumnGroups);

  const tableColumns = useMemo<ColumnDef<any>[]>(() => 
    columns.map(column => ({
      accessorKey: column,
      header: ({ column: tableColumn }) => {
        const group = columnGroups.find(g => g.columns.includes(column));
        return (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {group && (
                <button
                  onClick={() => toggleGroupExpansion(group.id)}
                  className="p-1 hover:bg-gray-100 rounded"
                >
                  {expandedGroups.has(group.id) ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>
              )}
              <span>{column}</span>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => tableColumn.toggleSorting()}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <ArrowUpDown className="w-4 h-4" />
              </button>
              <button
                onClick={() => toggleColumnVisibility(column)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                {tableColumn.getIsVisible() ? (
                  <Eye className="w-4 h-4" />
                ) : (
                  <EyeOff className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        );
      },
      cell: info => info.getValue(),
      size: 200,
      minSize: 100,
      maxSize: 400,
    })),
    [columns, columnGroups, expandedGroups]
  );

  const table = useReactTable({
    data,
    columns: tableColumns,
    state: {
      sorting,
      globalFilter,
      columnVisibility,
    },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onColumnVisibilityChange: setColumnVisibility,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    columnResizeMode,
    enableColumnResizing: true,
  });

  const toggleGroupExpansion = (groupId: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(groupId)) {
        next.delete(groupId);
      } else {
        next.add(groupId);
      }
      return next;
    });
  };

  const toggleColumnVisibility = (columnId: string) => {
    setColumnVisibility(prev => ({
      ...prev,
      [columnId]: !prev[columnId],
    }));
  };

  const renderColumnGroups = (groups: ColumnGroup[], level = 0) => {
    return (
      <div className="space-y-2 pl-4">
        {groups.map(group => (
          <div key={group.id} className="space-y-2">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => toggleGroupExpansion(group.id)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                {expandedGroups.has(group.id) ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>
              <span className="font-medium">{group.title}</span>
            </div>
            {expandedGroups.has(group.id) && (
              <>
                {group.subGroups && renderColumnGroups(group.subGroups, level + 1)}
                <div className="pl-4 space-y-1">
                  {group.columns.map(column => (
                    <div key={column} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={!columnVisibility[column]}
                        onChange={() => toggleColumnVisibility(column)}
                        className="rounded border-gray-300"
                      />
                      <span>{column}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between pb-4">
        <div className="flex items-center space-x-2">
          <Search className="w-5 h-5 text-gray-500" />
          <input
            type="text"
            value={globalFilter}
            onChange={e => setGlobalFilter(e.target.value)}
            placeholder="Search all columns..."
            className="border rounded-md px-3 py-2 w-64"
          />
        </div>
        <details className="relative">
          <summary className="list-none cursor-pointer">
            <button className="px-4 py-2 bg-gray-100 rounded-md hover:bg-gray-200">
              Column Settings
            </button>
          </summary>
          <div className="absolute right-0 mt-2 w-64 bg-white rounded-md shadow-lg border p-4 z-10">
            {renderColumnGroups(columnGroups)}
          </div>
        </details>
      </div>

      <div className="rounded-md border overflow-auto">
        <table 
          className="w-full text-sm"
          style={{ width: table.getCenterTotalSize() }}
        >
          <thead className="bg-gray-100 border-b">
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th
                    key={header.id}
                    className="px-4 py-3 text-left font-medium text-gray-700 relative"
                    style={{
                      width: header.getSize(),
                    }}
                  >
                    {header.isPlaceholder ? null : (
                      <>
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )}
                        <div
                          onMouseDown={header.getResizeHandler()}
                          onTouchStart={header.getResizeHandler()}
                          className={`absolute right-0 top-0 h-full w-1 cursor-col-resize select-none touch-none ${
                            header.column.getIsResizing() ? 'bg-blue-500' : 'bg-gray-200'
                          }`}
                        />
                      </>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map(row => (
              <tr key={row.id} className="border-b last:border-b-0 hover:bg-gray-50">
                {row.getVisibleCells().map(cell => (
                  <td
                    key={cell.id}
                    className="px-4 py-3"
                    style={{
                      width: cell.column.getSize(),
                    }}
                  >
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};